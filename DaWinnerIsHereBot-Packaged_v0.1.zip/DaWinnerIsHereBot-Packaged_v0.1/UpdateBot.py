import os
import asyncio
from os import system

system('pip -U pip')
asyncio.sleep(10)
system('pip install discord')
asyncio.sleep(10)
system('pip install -U discord')
asyncio.sleep(10)
