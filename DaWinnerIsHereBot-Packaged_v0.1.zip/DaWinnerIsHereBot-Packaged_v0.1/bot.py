import discord
import random
from discord.ext import commands

client = commands.Bot(command_prefix = '<PREFIX>')

# <PREFIX>: The prefix that you want the bot to use.
# Example: client = commands.Bot(command_prefix = 'Bot, ')
# Usage: Bot, ping

passwordx = 'admin'

# Change 'admin' to whatever you want the password to be.

# <STATUSMODE>: The type of status the bot has. (Supported statuses: online,idle,dnd,invisible)
# <STATUSSTRG>: The status text that the bot has. (Supported type: string)
# <ONLINEMSG>: The text that displays in the prompt when the bot is online.

@client.event
async def on_ready():
    await client.change_presence(status=discord.Status.<STATUSMODE>, activity=discord.Game('<STATUSSTRG>'))
    print('<ONLINEMSG>')

@client.command()
@commands.has_permissions(administrator=True)
async def disable_cog(ctx,cog=None,password=None):
    await ctx.channel.purge(limit=1)
    if password == passwordx:
        client.unload_extension(f'cogs.{cog}')
        await ctx.send('Unloaded Cog.')
    else:
        await ctx.send('Invalid Password!')

@client.command()
@commands.has_permissions(administrator=True)
async def enable_cog(ctx,cog=None,password=None):
    await ctx.channel.purge(limit=1)
    if password == passwordx:
        client.load_extension(f'cogs.{cog}')
        await ctx.send('Loaded Cog.')
    else:
        await ctx.send('Invalid Password!')

@client.command()
async def ping(ctx):
    await ctx.send('Pong!')

@client.command()
async def botstatus(ctx, *, ng):
    await client.change_presence(status=discord.Status.online, activity=discord.Game(ng))

# <TOKEN>: The token the bot runs off of.

client.run('<TOKEN>')
