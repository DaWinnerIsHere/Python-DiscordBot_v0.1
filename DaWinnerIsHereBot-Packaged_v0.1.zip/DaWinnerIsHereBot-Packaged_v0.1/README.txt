In order to run the bot, you must have python installed. After installing python, run UpdateBot.py, as it will autoupdate and download your pip and discord.py.
After that, open bot.py with the text editor of your choice.
Edit the arguments with the followed instructions.
When you are happy with your changes, insert the token and run bot.py.